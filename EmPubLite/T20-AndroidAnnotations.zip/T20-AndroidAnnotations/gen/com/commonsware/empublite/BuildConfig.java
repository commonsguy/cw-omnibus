/** Automatically generated file. DO NOT MODIFY */
package com.commonsware.empublite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}